import sys
#from agent import Agent
import numpy as np
import tensorflow as tf
from tensorflow import keras
import pandas as pd
import numpy as np

a = None
i = 0
model = keras.models.load_model('./submission/mymodel')
last_ten = np.zeros(10)
for line in sys.stdin:
    row = line.split(',')
    row = np.array([float(x.strip()) for x in row])
    '''if not a:
        a = Agent(len(row))

    res = a.step(row)
    print(f"{res[0].name} {res[1]}")
    '''
    #seed(1)
    
    
    if i < 10:
        print(f"HOLD {0}")
        last_ten[i] = row[0] # this is 'close' stock price 
    else:
        last_ten = np.roll(last_ten, -1)
        last_ten[-1] = row[0]
        X_predict = np.array(last_ten).reshape((1, 10, 1)) / 200
        predictedVal = model.predict(X_predict) * 200
        diff = predictedVal-row[0]
        percent = diff/row[0]
        if percent<-0.02:
            negative = -1*percent
            #print(f"BUY {negative}")
            print(f"BUY 1")
        elif percent>0.02:
            print(f"SELL {percent}")

    i += 1
