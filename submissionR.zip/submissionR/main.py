import sys
#from agent import Agent
import numpy as np
import tensorflow as tf
from tensorflow import keras
import pandas as pd
import numpy as np

for line in sys.stdin:
    row = line.split(',')
    row = np.array([float(x.strip()) for x in row])
    '''if not a:
        a = Agent(len(row))

    res = a.step(row)
    print(f"{res[0].name} {res[1]}")
    '''
    #seed(1)
    rnum = np.random.rand()
    if rnum<0.33:
        print(f"BUY 1")
    elif rnum<0.67:
        print(f"SELL 1")
    else:
        print(f"HOLD 0")
